use `retail_events_db`;
-- Q1. Basic Filtering – High-Value Products
-- Find all event records where the base_price is greater than 1,000.
-- Display:
-- - event_id
-- - store_id
-- - product_code
-- - base_price
-- - promo_type

-- Concepts:
-- SELECT, WHERE, comparison operators.

-- ------------------------------------------------------------
-- 1ans.
select event_id,store_id,product_code,base_price,promo_type
from fact_events
where base_price > 1000;

-- Q2. Sorting Promotional Events
-- Display all events where quantity sold after the promotion was greater than 100.

-- Display:
-- - event_id
-- - product_code
-- - promo_type
-- - quantity_sold(before_promo)
-- - quantity_sold(after_promo)

-- Sort by quantity_sold(after_promo) in descending order.

-- Concepts:
-- WHERE, ORDER BY, DESC.

-- ------------------------------------------------------------
-- 2Ans
select event_id,product_code,promo_type,`quantity_sold(before_promo)`,`quantity_sold(after_promo)`
from fact_events
where `quantity_sold(after_promo)` > 100
order by `quantity_sold(after_promo)` DESC;

-- Q3. DISTINCT Promotion Types
-- Find all unique promotion types used in the dataset.

-- Display only the unique promo_type values.

-- Concepts:
-- DISTINCT.

-- ------------------------------------------------------------
-- 3Ans
select distinct promo_type
from fact_events;

-- Q4. Basic Aggregation
-- Calculate the following for the complete fact_events table:

-- - Total number of events
-- - Total quantity sold before promotion
-- - Total quantity sold after promotion
-- - Average base price
-- - Maximum base price
-- - Minimum base price

-- Return all metrics in one row.

-- Concepts:
-- COUNT, SUM, AVG, MAX, MIN.

-- 4Ans
select COUNT(`event_id`) AS Total_Events,
sum(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
sum(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
avg(base_price) AS Average_Base_Price,
max(base_price) AS Maximum_Base_Price,
min(base_price) AS Minimum_Base_Price
from fact_events;


-- Q5. Sales Volume by Promotion Type
-- For each promo_type, calculate:

-- - Number of events
-- - Total quantity sold before promotion
-- - Total quantity sold after promotion

-- Sort by total quantity sold after promotion in descending order.

-- Concepts:
-- GROUP BY, COUNT, SUM, ORDER BY.

-- ------------------------------------------------------------
-- 5Ans
select COUNT(`event_id`) AS Total_Events,
	sum(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
	sum(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
	Promo_type
from fact_events
group by Promo_type
order by Total_Quantity_After_Promo Desc;

-- Q6. Promotion Uplift
-- For every promotion type, calculate:

-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity increase/decrease

-- Use:

-- Quantity Change = After Promo Quantity - Before Promo Quantity

-- Display:
-- - promo_type
-- - total_before
-- - total_after
-- - quantity_change

-- Sort by quantity_change descending.

-- Concepts:
-- GROUP BY, SUM, arithmetic calculations, aliases.

-- ------------------------------------------------------------
-- 6Ans
SELECT
    promo_type,
    SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
    SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
    SUM(`quantity_sold(after_promo)`) 
      - SUM(`quantity_sold(before_promo)`) AS change_in_quantity
FROM fact_events
GROUP BY promo_type
ORDER BY change_in_quantity DESC;

-- Q7. Product Performance
-- Using fact_events and dim_products, calculate total quantity sold after promotion for every product.

-- Display:
-- - product_code
-- - product_name
-- - category
-- - total quantity after promotion

-- Sort by total quantity after promotion descending.

-- Concepts:
-- INNER JOIN, GROUP BY, SUM, ORDER BY.

-- ------------------------------------------------------------
-- 7Ans
select dim_products.product_code,dim_products.product_name,dim_products.category,SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo
from fact_events
join dim_products on fact_events.product_code = dim_products.product_code
-- group by dim_products.product_code
GROUP BY
    dim_products.product_code,
    dim_products.product_name,
    dim_products.category
order by Total_Quantity_After_Promo Desc;

-- Q8. Category-Level Performance
-- Using fact_events and dim_products, calculate for every product category:

-- - Number of events
-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity change

-- Sort categories by total quantity after promotion descending.

-- Concepts:
-- JOIN, GROUP BY, SUM, COUNT, arithmetic calculations.

-- ------------------------------------------------------------
-- 8Ans
select Count(Event_id) AS Number_of_Events,dim_products.category,SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
    SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
    SUM(`quantity_sold(after_promo)`) 
      - SUM(`quantity_sold(before_promo)`) AS change_in_quantity
from fact_events
join dim_products on fact_events.product_code = dim_products.product_code
group by dim_products.category
order by Total_Quantity_After_Promo Desc;      

-- Q9. Store Performance
-- Using fact_events and dim_stores, calculate for every city:

-- - Number of promotional events
-- - Total quantity before promotion
-- - Total quantity after promotion

-- Display:
-- - city
-- - event_count
-- - total_before
-- - total_after

-- Sort cities by total_after descending.

-- Concepts:
-- JOIN, GROUP BY, aggregation, ORDER BY.

-- ------------------------------------------------------------
-- 9Ans
select COUNT(event_id) AS Number_of_Promotional_Events,dim_stores.city,SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
    SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo
from fact_events
join dim_stores on fact_events.store_id = dim_stores.store_id
group by dim_stores.city
order by Total_Quantity_After_Promo desc;    

-- Q10. Campaign Performance
-- Using fact_events and dim_campaigns, calculate for each campaign:

-- - Campaign name
-- - Start date
-- - End date
-- - Number of events
-- - Total quantity before promotion
-- - Total quantity after promotion

-- Sort by total quantity after promotion descending.

-- Concepts:
-- JOIN, GROUP BY, date columns, aggregation.

-- ------------------------------------------------------------
-- 10Ans
SELECT
    COUNT(fact_events.event_id) AS Number_of_events,
    dim_campaigns.campaign_name,
    dim_campaigns.start_date,
    dim_campaigns.end_date,
    SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
    SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo
FROM fact_events
JOIN dim_campaigns
    ON fact_events.campaign_id = dim_campaigns.campaign_id
GROUP BY
    dim_campaigns.campaign_name,
    dim_campaigns.start_date,
    dim_campaigns.end_date
ORDER BY Total_Quantity_After_Promo DESC;  

-- Q11. Product Category with HAVING
-- Find product categories where the total quantity sold after promotion is greater than 1,000.

-- Display:
-- - category
-- - total quantity after promotion
-- - average base price

-- Sort by total quantity after promotion descending.

-- Concepts:
-- JOIN, GROUP BY, HAVING, AVG, SUM.

-- ------------------------------------------------------------
-- 11Ans
select dim_products.category,
	   SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
       avg(fact_events.base_price)
from fact_events
join dim_products on fact_events.product_code = dim_products.product_code
group by dim_products.category
having Total_Quantity_After_Promo > 1000
order by Total_Quantity_After_Promo desc;

-- Q12. Store + Category Analysis
-- Using fact_events, dim_stores and dim_products, calculate total quantity sold after promotion for every combination of:

-- - City
-- - Product category

-- Display:
-- - city
-- - category
-- - total quantity after promotion

-- Sort first by city and then by total quantity descending.

-- Concepts:
-- Multiple JOINs, GROUP BY, ORDER BY.

-- ------------------------------------------------------------
-- 12Ans
select dim_stores.city,
	   dim_products.category,
       SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo
from fact_events
join dim_stores on fact_events.store_id = dim_stores.store_id
join dim_products on fact_events.product_code = dim_products.product_code
group by dim_stores.city,
		 dim_products.category
order by dim_stores.city,
		 Total_Quantity_After_Promo desc;
       
-- Q13. Promotion Effectiveness by Product
-- For each product, calculate:

-- - Product name
-- - Category
-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity change
-- - Percentage change

-- Use:

-- Percentage Change =
-- ((After Promo - Before Promo) / Before Promo) * 100

-- Handle division by zero appropriately.

-- Sort by percentage change descending.

-- Concepts:
-- JOIN, GROUP BY, arithmetic calculations, NULLIF, percentage calculations.

-- ------------------------------------------------------------ 
-- 13Ans
select ((SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`))
 / NULLIF(SUM(`quantity_sold(before_promo)`), 0) * 100) AS Percentage_change,
	   dim_products.product_name,
       dim_products.category,
       SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
       SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
       SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`) AS change_in_quantity
from fact_events
join dim_products on fact_events.product_code = dim_products.product_code
group by dim_products.product_name,
       dim_products.category
order by percentage_change desc;

-- Q14. Campaign and Promotion Type Analysis
-- For each campaign and promo_type combination, calculate:

-- - Number of events
-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity change

-- Display:
-- - campaign_name
-- - promo_type
-- - event_count
-- - total_before
-- - total_after
-- - quantity_change

-- Sort by campaign_name and quantity_change descending.

-- Concepts:
-- Multiple GROUP BY columns, JOIN, aggregation, ORDER BY.

-- ------------------------------------------------------------     

-- 14Ans
select count(event_id) As Number_of_events,
	   dim_campaigns.campaign_name,
       fact_events.promo_type,
       SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
       SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
       SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`) AS change_in_quantity
from fact_events
join dim_campaigns on fact_events.campaign_id = dim_campaigns.campaign_id
group by   dim_campaigns.campaign_name,
           promo_type     
order by dim_campaigns.campaign_name desc,
          change_in_quantity desc;        
          
-- Q15. Product Revenue Before and After Promotion
-- For each product, calculate:

-- 1. Revenue before promotion =
--    base_price × quantity_sold(before_promo)

-- 2. Revenue after promotion =
--    base_price × quantity_sold(after_promo)

-- 3. Revenue difference =
--    Revenue after - Revenue before

-- Display:
-- - product_name
-- - category
-- - revenue_before
-- - revenue_after
-- - revenue_difference

-- Sort by revenue_difference descending.

-- Concepts:
-- JOIN, GROUP BY, SUM, arithmetic calculations, aliases.

-- ------------------------------------------------------------        
-- 15 Ans
select dim_products.product_name,
       dim_products.category,
       sum(
       fact_events.base_price * `quantity_sold(before_promo)`
       ) as Revenue_before_promotion,
       sum(
       fact_events.base_price * `quantity_sold(after_promo)`
       ) as Revenue_after_promotion,
      sum(
       fact_events.base_price * `quantity_sold(before_promo)`) -
       sum(fact_events.base_price * `quantity_sold(after_promo)`
       )as Revenue_difference
from  fact_events
join dim_products on fact_events.product_code = dim_products.product_code
group by dim_products.product_name,
       dim_products.category
order by Revenue_difference Desc;       

-- Q16. Classify Promotion Performance
-- For every promotion type, calculate total quantity before and after promotion.

-- Then classify the promotion using CASE:

-- - Percentage change >= 50% → "High Impact"
-- - Percentage change >= 20% → "Medium Impact"
-- - Percentage change < 20% → "Low Impact"

-- Display:
-- - promo_type
-- - total_before
-- - total_after
-- - percentage_change
-- - performance_category

-- Sort by percentage_change descending.

-- Concepts:
-- GROUP BY, CASE, arithmetic calculations, NULLIF, aliases.

-- 16Ans
select promo_type,
	   SUM(`quantity_sold(before_promo)`) AS Total_Quantity_Before_Promo,
       SUM(`quantity_sold(after_promo)`) AS Total_Quantity_After_Promo,
       ((SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`)) / NULLIF(SUM(`quantity_sold(before_promo)`), 0) * 100) AS Percentage_change,
       case 
			when ((SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`)) / NULLIF(SUM(`quantity_sold(before_promo)`), 0) * 100) >= 50
            then "High_Impact"
			when ((SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`)) / NULLIF(SUM(`quantity_sold(before_promo)`), 0) * 100) >= 20
			then "Medium_Impact"
				else "Low_Impact"
        end
from fact_events
group by promo_type
order by Percentage_change desc; 


-- Q17. Top Products Within Each Category
-- Using a CTE:

-- 1. Calculate total quantity sold after promotion for every product.
-- 2. Rank products within each category based on total quantity sold after promotion.
-- 3. Return only the top 2 products from every category.

-- Display:
-- - category
-- - product_name
-- - total_quantity_after
-- - category_rank

-- Concepts:
-- CTE, JOIN, GROUP BY, DENSE_RANK/ROW_NUMBER,
-- PARTITION BY, window functions.

-- ------------------------------------------------------------
-- 17Ans
WITH product_totals AS (
    SELECT
        dp.category,
        dp.product_name,
        dp.product_code,
        SUM(fe.`quantity_sold(after_promo)`) AS total_quantity_after
    FROM fact_events fe
    JOIN dim_products dp
        ON fe.product_code = dp.product_code
    GROUP BY
        dp.category,
        dp.product_name,
        dp.product_code
),

ranked_products AS (
    SELECT
        category,
        product_name,
        total_quantity_after,
        DENSE_RANK() OVER (
            PARTITION BY category
            ORDER BY total_quantity_after DESC
        ) AS category_rank
    FROM product_totals
)

SELECT
    category,
    product_name,
    total_quantity_after,
    category_rank
FROM ranked_products
WHERE category_rank <= 2
ORDER BY
    category,
    category_rank;
 

-- Q18. Best-Performing Stores Within Each City
-- Calculate total quantity sold after promotion for each store.

-- Join dim_stores to obtain the city.

-- Then rank stores within each city based on total quantity sold after promotion.

-- Return the top 2 stores from each city.

-- Display:
-- - city
-- - store_id
-- - total_quantity_after
-- - city_rank

-- Concepts:
-- JOIN, CTE, GROUP BY, window functions,
-- PARTITION BY, RANK/DENSE_RANK.

-- ------------------------------------------------------------
-- 18Ans
WITH store_totals AS (
    SELECT
        ds.city,
        fe.store_id,
        SUM(fe.`quantity_sold(after_promo)`) AS total_quantity_after
    FROM fact_events fe
    JOIN dim_stores ds
        ON fe.store_id = ds.store_id
    GROUP BY
        ds.city,
        fe.store_id
),

ranked_stores AS (
    SELECT
        city,
        store_id,
        total_quantity_after,
        DENSE_RANK() OVER (
            PARTITION BY city
            ORDER BY total_quantity_after DESC
        ) AS city_rank
    FROM store_totals
)

SELECT
    city,
    store_id,
    total_quantity_after,
    city_rank
FROM ranked_stores
WHERE city_rank <= 2
ORDER BY
    city,
    city_rank;
 
-- Q19. Campaign-Level Product Performance
-- For every campaign and product:

-- Calculate:
-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity change
-- - Percentage change

-- Then rank products within each campaign based on percentage change.

-- Return the top 3 products for every campaign.

-- Display:
-- - campaign_name
-- - product_name
-- - total_before
-- - total_after
-- - quantity_change
-- - percentage_change
-- - campaign_rank

-- Concepts:
-- Multiple JOINs, CTE, GROUP BY, arithmetic calculations,
-- NULLIF, window functions, PARTITION BY, ranking.

-- ------------------------------------------------------------
-- 19Ans
WITH product_performance AS (
    SELECT
        dc.campaign_name,
        dp.product_name,
        dp.product_code,

        SUM(fe.`quantity_sold(before_promo)`) AS total_before,
        SUM(fe.`quantity_sold(after_promo)`) AS total_after

    FROM fact_events fe

    JOIN dim_campaigns dc
        ON fe.campaign_id = dc.campaign_id

    JOIN dim_products dp
        ON fe.product_code = dp.product_code

    GROUP BY
        dc.campaign_name,
        dp.product_name,
        dp.product_code
),

calculated AS (
    SELECT
        campaign_name,
        product_name,
        total_before,
        total_after,

        total_after - total_before AS quantity_change,

        (
            (total_after - total_before)
            / NULLIF(total_before, 0)
            * 100
        ) AS percentage_change

    FROM product_performance
),

ranked AS (
    SELECT
        *,
        DENSE_RANK() OVER (
            PARTITION BY campaign_name
            ORDER BY percentage_change DESC
        ) AS campaign_rank
    FROM calculated
)

SELECT
    campaign_name,
    product_name,
    total_before,
    total_after,
    quantity_change,
    ROUND(percentage_change, 2) AS percentage_change,
    campaign_rank

FROM ranked

WHERE campaign_rank <= 3

ORDER BY
    campaign_name,
    campaign_rank;
 

-- Q20. Complete Promotional Performance Analysis
-- Create a complete analytical report at the product-category level.

-- For every product, calculate:

-- - Product name
-- - Category
-- - Number of promotional events
-- - Total quantity before promotion
-- - Total quantity after promotion
-- - Quantity change
-- - Percentage change
-- - Revenue before promotion
-- - Revenue after promotion
-- - Revenue change
-- - Average base price
-- - Product rank within its category

-- Use:

-- Quantity Change =
-- Total After - Total Before

-- Percentage Change =
-- ((Total After - Total Before) / Total Before) * 100

-- Revenue Before =
-- SUM(base_price × quantity_before)

-- Revenue After =
-- SUM(base_price × quantity_after)

-- Revenue Change =
-- Revenue After - Revenue Before

-- Then:

-- 1. Rank products within each category by Revenue Change.
-- 2. Return only the top 2 products from each category.
-- 3. Use appropriate handling for division by zero.

-- Concepts:
-- - Multiple JOINs
-- - CTEs
-- - GROUP BY
-- - COUNT
-- - SUM
-- - AVG
-- - CASE
-- - NULLIF
-- - Arithmetic calculations
-- - Percentage calculations
-- - Window functions
-- - PARTITION BY
-- - DENSE_RANK / ROW_NUMBER
-- - Filtering ranked results
-- - Business analysis
-- 20Ans
WITH product_summary AS (
    SELECT
        dp.product_code,
        dp.product_name,
        dp.category,

        COUNT(fe.event_id) AS promotional_events,

        SUM(fe.`quantity_sold(before_promo)`) AS total_before,
        SUM(fe.`quantity_sold(after_promo)`) AS total_after,

        AVG(fe.base_price) AS average_base_price,

        SUM(
            fe.base_price * fe.`quantity_sold(before_promo)`
        ) AS revenue_before,

        SUM(
            fe.base_price * fe.`quantity_sold(after_promo)`
        ) AS revenue_after

    FROM fact_events fe

    JOIN dim_products dp
        ON fe.product_code = dp.product_code

    GROUP BY
        dp.product_code,
        dp.product_name,
        dp.category
),

calculated AS (
    SELECT
        product_code,
        product_name,
        category,
        promotional_events,
        total_before,
        total_after,

        total_after - total_before AS quantity_change,

        (
            (total_after - total_before)
            / NULLIF(total_before, 0)
            * 100
        ) AS percentage_change,

        revenue_before,
        revenue_after,

        revenue_after - revenue_before AS revenue_change,

        average_base_price

    FROM product_summary
),

ranked AS (
    SELECT
        *,
        DENSE_RANK() OVER (
            PARTITION BY category
            ORDER BY revenue_change DESC
        ) AS category_rank

    FROM calculated
)

SELECT
    product_name,
    category,
    promotional_events,
    total_before,
    total_after,
    quantity_change,

    ROUND(percentage_change, 2) AS percentage_change,

    ROUND(revenue_before, 2) AS revenue_before,
    ROUND(revenue_after, 2) AS revenue_after,
    ROUND(revenue_change, 2) AS revenue_change,

    ROUND(average_base_price, 2) AS average_base_price,

    category_rank

FROM ranked

WHERE category_rank <= 2

ORDER BY
    category,
    category_rank;




       
       